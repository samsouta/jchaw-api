<?php echo e($slot); ?>

<?php /**PATH /Users/BIG-MOUSE/PROJECT/jelleryProject/api-jchaw/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>