<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/BIG-MOUSE/PROJECT/jelleryProject/api-jchaw/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>